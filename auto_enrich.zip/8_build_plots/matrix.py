import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import sys
import os

# Parse arguments
if len(sys.argv) < 2 or len(sys.argv) > 3:
    print(f"Usage: python {sys.argv[0]} <gene_matrix_file> [plot_title]")
    sys.exit(1)

input_file = sys.argv[1]
filename = os.path.basename(input_file)

# Use second argument as title if provided
plot_title = sys.argv[2] if len(sys.argv) == 3 else filename.split('.', 1)[1] if '.' in filename else filename

# Load gene presence matrix
df = pd.read_csv(input_file, sep="\t")

# Drop first two columns and last row (Total occurrences)
df_plot = df.iloc[:-1, 2:]
df_plot.index = df['Sample'][:-1]

# Safety check
if df_plot.empty:
    print(f"Error: gene matrix is empty after preprocessing. Skipping term {plot_title}")
    sys.exit(1)

# Build color-coded presence matrix
color_matrix = pd.DataFrame(index=df_plot.index,
                            columns=df_plot.columns,
                            dtype=object)

for idx in df_plot.index:
    if "down" in idx:
        color_matrix.loc[idx] = df_plot.loc[idx].replace({1: 'orange', 0: 'white'})
    elif "up" in idx:
        color_matrix.loc[idx] = df_plot.loc[idx].replace({1: 'blue', 0: 'white'})
    else:
        color_matrix.loc[idx] = df_plot.loc[idx].replace({1: 'gray', 0: 'white'})

fig, ax = plt.subplots(figsize=(8,6))

# Plot heatmap grid (white background)
sns.heatmap(df_plot*0, annot=False, linewidths=0.1, linecolor="gray",
                 cbar=False, square=False, cmap=["white"], ax=ax)

# Overlay colored squares
for y, sample in enumerate(color_matrix.index):
    for x, gene in enumerate(color_matrix.columns):
        rect = mpatches.Rectangle((x,y), 1, 1,
                                  facecolor=color_matrix.loc[sample, gene],
                                  edgecolor='gray')
        ax.add_patch(rect)

# Style axes
ax.set_xticklabels(ax.get_xticklabels(), rotation=90)
ax.set_yticklabels(ax.get_yticklabels(), rotation=0)
ax.set_xlabel("Genes")
ax.set_ylabel("Time points")
ax.set_title(plot_title, pad=30)  # title with padding

# Add legend for up/down-regulated genes
orange_patch = mpatches.Patch(color='orange', label='Down-regulated')
blue_patch   = mpatches.Patch(color='blue', label='Up-regulated')
fig.legend(handles=[orange_patch, blue_patch],
           fontsize=8,
           loc='upper center',
           bbox_to_anchor=(0.5, 0.93),  # adjust vertical position
           ncol=2,
           frameon=False)

plt.subplots_adjust(top=0.85)

fig.tight_layout()
fig.savefig("my_matrix.pdf", bbox_inches="tight")
