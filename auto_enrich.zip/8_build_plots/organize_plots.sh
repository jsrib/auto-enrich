#!/bin/bash
shopt -s nullglob

if [[ $# -ne 2 ]]; then
	printf "Usage: %s <results_members_dir> <method>\n" "$0"
	exit 1
fi

input_dir="$1"
method="$2"
out_dir="/data/plots_and_gene_matrices/${method}"

if [ -d "${out_dir}" ]; then
	printf "Warning: Directory for '%s' found, cannot replace existing (%s).\n" "$method" "out_dir"
	exit 1
fi

while read -r term; do
	safe_term="${term//[:\/]/_}"
	countsf="$input_dir"/counts."$safe_term"
	membersf="$input_dir"/members."$safe_term"
	matrixf="$input_dir"/gene_matrix."$safe_term"
	plot=($input_dir/plot."$safe_term"*)
	matrixp=($input_dir/matrix."$safe_term"*)

	if [[ -f "$countsf" ]]; then
		name=$(sed -n '2p' "$countsf" | tr -d '\r')
		src=$(sed -n '4p' "$countsf" | tr -d '\r')
	else
		printf "Warning: No counts file for %s" "$term"
		exit 1
	fi

	# Sanitize source and name for directories
	safe_src=$(printf "%s" "$src" | tr -cs '[:alnum:]_-' ' ')
	safe_name=$(printf "%s" "$term $name" | tr -cs '[:alnum:] _-' ' ')

	target_dir="$out_dir/$safe_src/$safe_name/"
	mkdir -p "$target_dir" 
	plots_dir="$out_dir/$safe_src/0_plots/"
	mkdir -p "$plots_dir"

	# Copy only existing files
	cp -u "$countsf" "$target_dir"/
	[[ -f "$membersf" ]] && cp -u "$membersf" "$target_dir"
	[[ -f "$matrixf" ]] && cp -u "$matrixf" "$target_dir"
	[[ ${#matrixp[@]} -gt 0 ]] && cp -u "${matrixp[@]}" "$target_dir"
	[[ ${#plot[@]} -gt 0 ]] && cp -u "${plot[@]}" "$target_dir"
	[[ ${#plot[@]} -gt 0 ]] && cp -u "${plot[@]}" "$plots_dir"

	# printf "Copied files for term %s' to '%s'\n" "'$term" "$target_dir"
done < tmp4
