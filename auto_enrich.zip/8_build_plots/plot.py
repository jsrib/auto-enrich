import matplotlib.pyplot as plt
import pandas as pd
import sys

title = sys.argv[1] if len(sys.argv) > 1 else "GeneIDs Map by Group"

# Prepare data
data = []
with open('tmp_term') as f:  # use tmp_term file in directory
	for line in f:
		line = line.strip()
		if not line:
			continue
		info, value = line.rsplit(maxsplit=1)
		value = int(value)
		fields = info.split('-')
		sample = f"{fields[0]}-{fields[1]}"
		group = fields[2].split('_')[0]
		data.append((sample, group, value))

df = pd.DataFrame(data, columns=['sample', 'group', 'value'])

# Keep samples in order of first appearance
sample_order = df['sample'].drop_duplicates().tolist()

# Pivot so each group becomes a column, maintaining sample order
pivot = df.pivot(index='sample', columns='group', values='value').loc[sample_order]

# Define color mapping
color_map = {
	"up": "blue",
	"down": "orange"
}

# Plot as line graph with custom colors
ax = pivot.plot(
	marker='o',
	linewidth=2,
	color=[color_map.get(col, "gray") for col in pivot.columns]  # fallback to gray
)

plt.xlabel('Time points')
plt.ylabel('Number of genes')
plt.title(title)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.legend(title='Group')
plt.savefig("my_plot.pdf", bbox_inches='tight')
